<!doctype html>
<html lang="bn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'আমার ফার্ম — অ্যাডমিন প্যানেল'); ?></title>
    <?php
        $siteFavicon = \App\Models\Setting::get('site_favicon');
    ?>
    <?php if($siteFavicon): ?>
        <link rel="icon" href="<?php echo e(asset('storage/' . $siteFavicon)); ?>">
    <?php else: ?>
        <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🌱</text></svg>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<div class="app">
    <?php echo $__env->make('components.sidebar', ['active' => $activeTab ?? 'dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <?php echo $__env->make('components.topbar', ['title' => $title ?? 'ড্যাশবোর্ড'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div id="app">
            <?php echo $__env->make('components.flash-message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>

<div class="sidebar-backdrop" id="sidebar-backdrop"></div>

<div class="modal-wrap" id="modal">
    <?php echo $__env->yieldContent('modal'); ?>
</div>

<div class="toast" id="toast"></div>

<script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('components.idle-session-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/layouts/admin.blade.php ENDPATH**/ ?>