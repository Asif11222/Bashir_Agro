<?php if(session('success')): ?>
    <div class="alert-success" style="margin: 0 0 16px 0;">
        <?php echo e(session('success')); ?>

    </div>
    <input type="hidden" id="flash-toast-message" value="<?php echo e(session('success')); ?>">
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert-danger" style="margin: 0 0 16px 0;">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(isset($errors) && $errors->any()): ?>
    <div class="alert-danger" style="margin: 0 0 16px 0;">
        <ul style="margin:0;padding-left:18px">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/components/flash-message.blade.php ENDPATH**/ ?>