<!doctype html>
<html lang="bn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
        $siteFavicon = \App\Models\Setting::get('site_favicon');
        $siteLogo = \App\Models\Setting::get('site_logo');
        $farmName = \App\Models\Setting::get('farm_name', 'আমার ফার্ম');
    ?>
    <title>লগইন — <?php echo e($farmName); ?> অ্যাডমিন প্যানেল</title>
    <?php if($siteFavicon): ?>
        <link rel="icon" href="<?php echo e(asset('storage/' . $siteFavicon)); ?>">
    <?php else: ?>
        <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🌱</text></svg>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <style>
        .password-field-wrap {
            position: relative;
            display: flex;
            align-items: center;
        }
        .password-field-wrap .input {
            padding-right: 42px;
        }
        .password-toggle-btn {
            position: absolute;
            right: 6px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: 0;
            color: #6f7f77;
            padding: 6px 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border-radius: 6px;
            transition: color 0.15s ease, background-color 0.15s ease;
        }
        .password-toggle-btn:hover {
            color: #0b8f4b;
            background-color: #f0f7f2;
        }
        .password-toggle-btn:focus-visible {
            outline: 2px solid #31a866;
            outline-offset: 1px;
        }
    </style>
</head>
<body>
<div class="auth-wrap">
    <div class="auth-card">
        <div class="auth-brand">
            <?php if($siteLogo): ?>
                <div style="width: 58px; height: 58px; border-radius: 16px; background: #fff; display: flex; align-items: center; justify-content: center; overflow: hidden; margin: 0 auto 12px; padding: 4px; box-shadow: 0 4px 14px rgba(6,78,47,0.12); box-sizing: border-box;">
                    <img src="<?php echo e(asset('storage/' . $siteLogo)); ?>" alt="<?php echo e($farmName); ?>" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                </div>
            <?php else: ?>
                <div class="leaf">🌱</div>
            <?php endif; ?>
            <h1><?php echo e($farmName); ?></h1>
            <p>কৃষি ব্যবস্থাপনা অ্যাডমিন প্যানেলে লগইন করুন</p>
        </div>

        <?php if(request()->query('reason') === 'idle'): ?>
            <div class="notice warn" style="margin-bottom: 16px; font-size: 13px; line-height: 1.45; display: flex; align-items: flex-start; gap: 8px;">
                <span style="font-size: 16px;">⏱</span>
                <div>
                    <b>সেশনের মেয়াদ শেষ হয়েছে</b><br>
                    নিষ্ক্রিয় থাকার কারণে অ্যাকাউন্ট সুরক্ষার্থে সেশন সমাপ্ত হয়েছে। অনুগ্রহ করে পুনরায় লগইন করুন।
                </div>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div style="margin-bottom: 14px;">
                <label class="label" for="email">ইমেইল বা মোবাইল নম্বর <span class="req">*</span></label>
                <input class="input" id="email" type="text" name="email" value="<?php echo e(old('email', 'admin@bashiragro.com')); ?>" required autofocus placeholder="admin@bashiragro.com">
            </div>

            <div style="margin-bottom: 16px;">
                <label class="label" for="password">পাসওয়ার্ড <span class="req">*</span></label>
                <div class="password-field-wrap">
                    <input class="input" id="password" type="password" name="password" required placeholder="••••••••">
                    <button type="button" class="password-toggle-btn" id="togglePasswordBtn" title="পাসওয়ার্ড দেখুন" aria-label="পাসওয়ার্ড দেখুন">
                        <svg class="eye-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                        <svg class="eye-slash-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display: none;">
                            <path d="m9.88 9.88a3 3 0 1 0 4.24 4.24"/>
                            <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/>
                            <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/>
                            <line x1="2" x2="22" y1="2" y2="22"/>
                        </svg>
                    </button>
                </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 13px; color: var(--muted);">
                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <span>মনে রাখুন</span>
                </label>
            </div>

            <button type="submit" class="btn primary" style="width: 100%; padding: 11px; font-size: 15px;">
                লগইন করুন
            </button>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const pwdInput = document.getElementById('password');
        const toggleBtn = document.getElementById('togglePasswordBtn');
        if (!toggleBtn || !pwdInput) return;

        const eyeIcon = toggleBtn.querySelector('.eye-icon');
        const eyeSlashIcon = toggleBtn.querySelector('.eye-slash-icon');

        toggleBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const isPassword = pwdInput.type === 'password';
            pwdInput.type = isPassword ? 'text' : 'password';

            if (eyeIcon && eyeSlashIcon) {
                eyeIcon.style.display = isPassword ? 'none' : 'block';
                eyeSlashIcon.style.display = isPassword ? 'block' : 'none';
            }

            const label = isPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন';
            toggleBtn.setAttribute('title', label);
            toggleBtn.setAttribute('aria-label', label);
            pwdInput.focus();
        });
    });
</script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/auth/login.blade.php ENDPATH**/ ?>