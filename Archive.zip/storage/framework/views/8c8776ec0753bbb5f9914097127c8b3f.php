
<?php if($assignment->status === 'completed' && $assignment->submission): ?>
    <?php
        $geoOk = $assignment->submission->geofence_passed;
        $late = $assignment->submission->is_late;
    ?>
    <div style="margin-top:4px;font-size:10px;line-height:1.4;color:<?php echo e((!$geoOk || $late) ? 'var(--red)' : 'var(--g700)'); ?>">
        <?php echo e($geoOk ? '✓ সঠিক লোকেশন' : '✕ লোকেশনের বাইরে'); ?>

        · <?php echo e($late ? 'সময় পেরিয়েছে' : 'সময়ের মধ্যে'); ?>

    </div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/components/submission-health.blade.php ENDPATH**/ ?>