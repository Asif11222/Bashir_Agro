<?php $__env->startSection('title', 'ড্যাশবোর্ড — আমার ফার্ম'); ?>

<?php $__env->startSection('content'); ?>
<div class="page">
    <div class="head">
        <div>
            <h1>ড্যাশবোর্ড</h1>
            <p>আজকের ফার্ম অপারেশন, কৃষক ও কাজের অবস্থা এক নজরে</p>
        </div>
        <div class="actions">
            <a href="<?php echo e(route('admin.farmers.create')); ?>" class="btn soft">+ নতুন কৃষক</a>
            <a href="<?php echo e(route('admin.tasks.create')); ?>" class="btn primary">+ নতুন কাজ</a>
        </div>
    </div>

    <div class="grid cols-4">
        <div class="card kpi">
            <span class="iconbox">♟</span>
            <div>
                <b><?php echo e($activeFarmers); ?></b>
                <small>সক্রিয় কৃষক</small>
            </div>
            <span class="trend">+<?php echo e($newFarmersThisMonth); ?> এই মাসে</span>
        </div>

        <div class="card kpi">
            <span class="iconbox">▣</span>
            <div>
                <b><?php echo e($todaysTasksCount); ?></b>
                <small>আজকের কাজ</small>
            </div>
            <span class="trend"><?php echo e($todaysCompletedCount); ?> সম্পন্ন</span>
        </div>

        <div class="card kpi">
            <span class="iconbox">⌖</span>
            <div>
                <b><?php echo e($activeLocations); ?></b>
                <small>সক্রিয় লোকেশন</small>
            </div>
            <span class="trend"><?php echo e($locationActivePercent); ?>% সক্রিয়</span>
        </div>

        <div class="card kpi">
            <span class="iconbox">⚠</span>
            <div>
                <b><?php echo e($attentionNeeded); ?></b>
                <small>মনোযোগ প্রয়োজন</small>
            </div>
            <?php if($todaysLateCount > 0): ?>
                <span class="trend" style="color:var(--red);background:#ffe8e6"><?php echo e($todaysLateCount); ?>টি দেরি</span>
            <?php else: ?>
                <span class="trend">সব ঠিক আছে</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid dashboard-grid section-gap">
        <div class="grid">
            <section class="card">
                <div class="card-title">
                    <div class="title-left">
                        <span class="iconbox">▣</span>
                        <div>
                            <h2>আজকের কাজ</h2>
                            <div class="sub">কাজের অবস্থা ও সময়সীমা (PostgreSQL থেকে রিয়েল-টাইম)</div>
                        </div>
                    </div>
                </div>

                <div class="tabs">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="tab <?php echo e(!$statusFilter ? 'active' : ''); ?>">
                        সব (<?php echo e($todaysTasksCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.dashboard', ['status' => 'in_progress'])); ?>" class="tab <?php echo e($statusFilter === 'in_progress' ? 'active' : ''); ?>">
                        চলমান (<?php echo e($todaysInProgressCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.dashboard', ['status' => 'late'])); ?>" class="tab <?php echo e($statusFilter === 'late' ? 'active' : ''); ?>">
                        দেরি (<?php echo e($todaysLateCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.dashboard', ['status' => 'completed'])); ?>" class="tab <?php echo e($statusFilter === 'completed' ? 'active' : ''); ?>">
                        সম্পন্ন (<?php echo e($todaysCompletedCount); ?>)
                    </a>
                </div>

                <div class="table-wrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>কৃষক</th>
                                <th>কাজ</th>
                                <th>লোকেশন</th>
                                <th>সময়</th>
                                <th>অবস্থা</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $todaysAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <b><?php echo e($assignment->farmer->full_name ?? 'অজ্ঞাত কৃষক'); ?></b>
                                        <?php if($assignment->farmer?->phone): ?>
                                            <br><small style="color:var(--muted)"><?php echo e($assignment->farmer->phone); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <b><?php echo e($assignment->taskTemplate->name ?? 'অজ্ঞাত কাজ'); ?></b>
                                        <br><small style="color:var(--muted)"><?php echo e($assignment->taskTemplate->task_code ?? ''); ?></small>
                                    </td>
                                    <td><?php echo e($assignment->location->name ?? 'অজ্ঞাত লোকেশন'); ?></td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($assignment->start_time)->format('H:i')); ?>

                                        <?php if($assignment->end_time): ?>
                                            - <?php echo e(\Carbon\Carbon::parse($assignment->end_time)->format('H:i')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo $__env->make('components.status-pill', [
                                            'status' => $assignment->status
                                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.submission-health', ['assignment' => $assignment], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.assignments.show', $assignment)); ?>" class="btn">
                                            দেখুন
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="empty">
                                        আজকের কোনো কাজ খুঁজে পাওয়া যায়নি।
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="card">
                <div class="card-title">
                    <div class="title-left">
                        <span class="iconbox">◉</span>
                        <div>
                            <h2>সাম্প্রতিক কার্যক্রম</h2>
                            <div class="sub">শেষ আপডেটগুলো (অ্যাক্টিভিটি লগ)</div>
                        </div>
                    </div>
                    <a href="<?php echo e(Route::has('admin.audit') ? route('admin.audit') : route('admin.dashboard')); ?>" class="btn soft" style="font-size:12px;padding:6px 12px;">
                        সব দেখুন →
                    </a>
                </div>
                <div class="timeline">
                    <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="event">
                            <p>
                                <b><?php echo e($activity->description); ?></b><br>
                                <small style="color:var(--muted)"><?php echo e($activity->user->name ?? 'সিস্টেম'); ?> • <?php echo e($activity->created_at->diffForHumans()); ?></small>
                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty">
                            কোনো সাম্প্রতিক কার্যক্রম পাওয়া যায়নি।
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>

        <div class="grid">
            <section class="card">
                <div class="card-title">
                    <div class="title-left">
                        <span class="iconbox">⚡</span>
                        <div>
                            <h2>দ্রুত কাজ</h2>
                            <div class="sub">সবচেয়ে বেশি ব্যবহৃত অ্যাকশন</div>
                        </div>
                    </div>
                </div>
                <div class="quick">
                    <a href="<?php echo e(route('admin.farmers.create')); ?>">
                        ♟<b>কৃষক যোগ করুন</b>
                        <small>নতুন কৃষক অ্যাকাউন্ট</small>
                    </a>
                    <a href="<?php echo e(route('admin.tasks.create')); ?>">
                        ▣<b>কাজ তৈরি করুন</b>
                        <small>কাজের টেমপ্লেট ও নিয়ম</small>
                    </a>
                    <a href="<?php echo e(route('admin.locations.create')); ?>">
                        ⌖<b>লোকেশন যোগ করুন</b>
                        <small>জিও-ফেন্সসহ</small>
                    </a>
                    <a href="<?php echo e(route('admin.assignments.create')); ?>">
                        ✓<b>কাজ বরাদ্দ করুন</b>
                        <small>এক কৃষককে এক কাজ</small>
                    </a>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/dashboard/index.blade.php ENDPATH**/ ?>