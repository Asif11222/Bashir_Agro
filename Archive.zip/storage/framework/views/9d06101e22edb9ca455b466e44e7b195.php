<?php $__env->startSection('title', 'কৃষক ব্যবস্থাপনা — আমার ফার্ম'); ?>

<?php $__env->startSection('content'); ?>
<div class="page">
    <div class="head">
        <div>
            <h1>কৃষক ব্যবস্থাপনা</h1>
            <p>কৃষক, অ্যাপ অ্যাক্সেস, বরাদ্দ ও বর্তমান কাজ পরিচালনা করুন</p>
        </div>
        <div class="actions">
            <a href="<?php echo e(route('admin.farmers.create')); ?>" class="btn primary">+ নতুন কৃষক</a>
        </div>
    </div>

    <section class="card">
        <div class="card-title">
            <div class="title-left">
                <span class="iconbox">♟</span>
                <div>
                    <h2>কৃষক তালিকা</h2>
                    <div class="sub">একজন কৃষক একাধিক কাজ করতে পারবেন; প্রতিটি কাজ একজন কৃষককেই বরাদ্দ হবে</div>
                </div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
                <form method="GET" action="<?php echo e(route('admin.farmers.index')); ?>" style="display:flex;gap:8px;">
                    <?php if($status): ?>
                        <input type="hidden" name="status" value="<?php echo e($status); ?>">
                    <?php endif; ?>
                    <input class="input" type="text" name="search" value="<?php echo e($search); ?>" placeholder="নাম, আইডি বা ফোন..." style="width:220px;padding:6px 10px;font-size:12px">
                    <button type="submit" class="btn soft" style="padding:6px 12px">খুঁজুন</button>
                    <?php if($search): ?>
                        <a href="<?php echo e(route('admin.farmers.index', array_filter(['status' => $status]))); ?>" class="btn" style="padding:6px 10px" title="সার্চ মুছুন">✕</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="tabs">
            <a href="<?php echo e(route('admin.farmers.index', array_filter(['search' => $search]))); ?>" class="tab <?php echo e(!$status ? 'active' : ''); ?>">
                সব কৃষক (<?php echo e($totalFarmersCount); ?>)
            </a>
            <a href="<?php echo e(route('admin.farmers.index', array_filter(['status' => 'active', 'search' => $search]))); ?>" class="tab <?php echo e($status === 'active' ? 'active' : ''); ?>">
                সক্রিয় (<?php echo e($activeFarmersCount); ?>)
            </a>
            <a href="<?php echo e(route('admin.farmers.index', array_filter(['status' => 'inactive', 'search' => $search]))); ?>" class="tab <?php echo e($status === 'inactive' ? 'active' : ''); ?>">
                নিষ্ক্রিয় (<?php echo e($inactiveFarmersCount); ?>)
            </a>
        </div>

        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>কৃষক</th>
                        <th>আইডি</th>
                        <th>প্রধান কার্যক্রম</th>
                        <th>লোকেশন</th>
                        <th>সক্রিয় কাজ</th>
                        <th>অ্যাপ</th>
                        <th>অবস্থা</th>
                        <th style="text-align:right">অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div style="display:flex;gap:10px;align-items:center;">
                                    <?php if($farmer->profile_photo_path): ?>
                                        <img src="<?php echo e(asset('storage/' . $farmer->profile_photo_path)); ?>" alt="<?php echo e($farmer->full_name); ?>" style="width:34px;height:34px;border-radius:50%;object-fit:cover;border:1px solid var(--line);">
                                    <?php else: ?>
                                        <div class="avatar" style="width:34px;height:34px;font-size:13px;flex:none;">
                                            <?php echo e(mb_substr($farmer->full_name, 0, 1)); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <b><?php echo e($farmer->full_name); ?></b>
                                        <br><small style="color:var(--muted)"><?php echo e($farmer->phone); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><span style="font-weight:600;color:var(--g800)"><?php echo e($farmer->farmer_code); ?></span></td>
                            <td><?php echo e($farmer->primary_activity); ?></td>
                            <td><?php echo e($farmer->farm_locations_count); ?></td>
                            <td>
                                <?php echo e($farmer->total_tasks - $farmer->completed_tasks); ?>

                                <br><small style="color:var(--muted)">অগ্রগতি: <?php echo e($farmer->taskProgressPercent()); ?>%</small>
                            </td>
                            <td>
                                <?php if($farmer->app_access_enabled): ?>
                                    <span class="pill"><span class="dot"></span>সক্রিয়</span>
                                <?php else: ?>
                                    <span class="pill red"><span class="dot"></span>ব্লক</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo $__env->make('components.status-pill', ['status' => $farmer->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </td>
                            <td style="text-align:right;">
                                <div style="display:inline-flex;gap:5px;">
                                    <a href="<?php echo e(route('admin.farmers.show', $farmer)); ?>" class="btn" style="padding:5px 9px;font-size:11px">দেখুন</a>
                                    <a href="<?php echo e(route('admin.farmers.edit', $farmer)); ?>" class="btn soft" style="padding:5px 9px;font-size:11px">সম্পাদনা</a>
                                    <form method="POST" action="<?php echo e(route('admin.farmers.destroy', $farmer)); ?>" style="display:inline;" onsubmit="return confirm('আপনি কি নিশ্চিতভাবে এই কৃষককে মুছে ফেলতে চান? এটি ডাটাবেজ থেকে স্থায়ীভাবে মুছে যাবে।');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn danger" style="padding:5px 9px;font-size:11px">মুছুন</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="empty">
                                কোনো কৃষক খুঁজে পাওয়া যায়নি।
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($farmers->hasPages()): ?>
            <div style="margin-top:20px;display:flex;justify-content:center;">
                <?php echo e($farmers->links()); ?>

            </div>
        <?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/farmers/index.blade.php ENDPATH**/ ?>