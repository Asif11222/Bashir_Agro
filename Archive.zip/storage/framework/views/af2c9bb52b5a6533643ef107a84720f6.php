<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'status' => 'active',
    'text' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'status' => 'active',
    'text' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $class = '';
    $label = $text;

    switch ($status) {
        case 'active':
        case 'completed':
        case 'পাস':
        case 'চালু':
        case 'অনুমোদিত':
            $class = '';
            $label = $label ?? ($status === 'active' ? 'সক্রিয়' : 'সম্পন্ন');
            break;
        case 'in_progress':
        case 'চলমান':
            $class = 'blue';
            $label = $label ?? 'চলমান';
            break;
        case 'pending':
        case 'অপেক্ষমাণ':
            $class = 'amber';
            $label = $label ?? 'অপেক্ষমাণ';
            break;
        case 'late':
        case 'দেরি':
        case 'inactive':
        case 'নিষ্ক্রিয়':
        case 'danger':
            $class = 'red';
            $label = $label ?? ($status === 'late' ? 'দেরি' : 'নিষ্ক্রিয়');
            break;
        default:
            $class = '';
            $label = $label ?? $status;
    }
?>

<span class="pill <?php echo e($class); ?>">
    <span class="dot"></span><?php echo e($label); ?>

</span>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/components/status-pill.blade.php ENDPATH**/ ?>