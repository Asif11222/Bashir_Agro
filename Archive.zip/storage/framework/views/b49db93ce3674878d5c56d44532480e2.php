<?php $__env->startSection('title', 'কাজ বরাদ্দ ব্যবস্থাপনা — আমার ফার্ম'); ?>

<?php $__env->startSection('content'); ?>
<div class="page">
    <div class="head">
        <div>
            <h1>কাজ বরাদ্দ ব্যবস্থাপনা</h1>
            <p>কৃষক, কাজের টেমপ্লেট ও ফার্ম লোকেশন সমন্বয়ে কাজের পূর্ণাঙ্গ সময়সূচি ও স্থিতি পরিচালনা করুন</p>
        </div>
        <div class="actions">
            <a href="<?php echo e(route('admin.assignments.create')); ?>" class="btn primary">+ নতুন কাজ বরাদ্দ</a>
        </div>
    </div>

    <div class="grid cols-2">
        <div style="grid-column: 1 / -1;">
            <section class="card">
                <div class="card-title">
                    <div class="title-left">
                        <span class="iconbox">✓</span>
                        <div>
                            <h2>বরাদ্দকৃত কার্যতালিকা</h2>
                            <div class="sub">কৃষক পর্যায়ে কাজের সময়সীমা ও অগ্রগতি ট্র্যাক করুন</div>
                        </div>
                    </div>
                </div>

                
                <div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap;">
                    <form method="GET" action="<?php echo e(route('admin.assignments.index')); ?>" style="display:flex;gap:8px;flex:1;flex-wrap:wrap;">
                        <?php if($status): ?>
                            <input type="hidden" name="status" value="<?php echo e($status); ?>">
                        <?php endif; ?>
                        <input class="input" type="text" name="search" value="<?php echo e($search); ?>" placeholder="কৃষক, কাজ বা লোকেশনের নাম দিয়ে খুঁজুন..." style="padding:7px 12px;font-size:12px;flex:1;min-width:200px;">
                        
                        <select name="priority" class="input" style="padding:7px 10px;font-size:12px;width:auto;" onchange="this.form.submit()">
                            <option value="">সকল অগ্রাধিকার</option>
                            <option value="normal" <?php echo e($priority === 'normal' ? 'selected' : ''); ?>>সাধারণ</option>
                            <option value="important" <?php echo e($priority === 'important' ? 'selected' : ''); ?>>গুরুত্বপূর্ণ</option>
                            <option value="urgent" <?php echo e($priority === 'urgent' ? 'selected' : ''); ?>>জরুরি</option>
                        </select>

                        <select name="date_filter" id="dateFilterSelect" class="input" style="padding:7px 10px;font-size:12px;width:auto;" onchange="handleDateFilterChange(this)">
                            <option value="">সকল তারিখ</option>
                            <option value="today" <?php echo e($dateFilter === 'today' ? 'selected' : ''); ?>>আজকের কাজ</option>
                            <option value="this_week" <?php echo e($dateFilter === 'this_week' ? 'selected' : ''); ?>>এই সপ্তাহের কাজ</option>
                            <option value="custom" <?php echo e($dateFilter === 'custom' ? 'selected' : ''); ?>>নির্দিষ্ট তারিখ</option>
                        </select>

                        <input type="date" id="customDateInput" name="date" class="input" value="<?php echo e($customDate); ?>" style="padding:6px 10px;font-size:12px;width:auto;display:<?php echo e($dateFilter === 'custom' ? 'inline-block' : 'none'); ?>;" onchange="this.form.submit()">

                        <button type="submit" class="btn soft" style="padding:7px 14px">ফিল্টার</button>
                        <?php if($search || $priority || $dateFilter): ?>
                            <a href="<?php echo e(route('admin.assignments.index', array_filter(['status' => $status]))); ?>" class="btn" style="padding:7px 12px" title="ফিল্টার মুছুন">✕ রিস্টার্ট</a>
                        <?php endif; ?>
                    </form>
                    <script>
                        function handleDateFilterChange(select) {
                            var dateInput = document.getElementById('customDateInput');
                            if (select.value === 'custom') {
                                if (dateInput) {
                                    dateInput.style.display = 'inline-block';
                                    dateInput.focus();
                                }
                            } else {
                                if (dateInput) {
                                    dateInput.style.display = 'none';
                                    dateInput.value = '';
                                }
                                select.form.submit();
                            }
                        }
                    </script>
                </div>

                
                <div class="tabs">
                    <a href="<?php echo e(route('admin.assignments.index', array_filter(['search' => $search, 'priority' => $priority, 'date_filter' => $dateFilter, 'date' => $customDate]))); ?>" class="tab <?php echo e(!$status ? 'active' : ''); ?>">
                        সব (<?php echo e($totalAssignmentsCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.assignments.index', array_filter(['status' => 'assigned', 'search' => $search, 'priority' => $priority, 'date_filter' => $dateFilter, 'date' => $customDate]))); ?>" class="tab <?php echo e($status === 'assigned' ? 'active' : ''); ?>">
                        বরাদ্দকৃত (<?php echo e($assignedCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.assignments.index', array_filter(['status' => 'in_progress', 'search' => $search, 'priority' => $priority, 'date_filter' => $dateFilter, 'date' => $customDate]))); ?>" class="tab <?php echo e($status === 'in_progress' ? 'active' : ''); ?>">
                        চলমান (<?php echo e($inProgressCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.assignments.index', array_filter(['status' => 'completed', 'search' => $search, 'priority' => $priority, 'date_filter' => $dateFilter, 'date' => $customDate]))); ?>" class="tab <?php echo e($status === 'completed' ? 'active' : ''); ?>">
                        সম্পন্ন (<?php echo e($completedCount); ?>)
                    </a>
                    <a href="<?php echo e(route('admin.assignments.index', array_filter(['status' => 'cancelled', 'search' => $search, 'priority' => $priority, 'date_filter' => $dateFilter, 'date' => $customDate]))); ?>" class="tab <?php echo e($status === 'cancelled' ? 'active' : ''); ?>">
                        বাতিল (<?php echo e($cancelledCount); ?>)
                    </a>
                </div>

                <div class="table-wrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>কৃষক</th>
                                <th>কাজের নাম</th>
                                <th>লোকেশন</th>
                                <th>তারিখ ও সময়</th>
                                <th>অগ্রাধিকার</th>
                                <th>অবস্থা</th>
                                <th>নিয়োজক</th>
                                <th style="text-align:right">অ্যাকশন</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <b><?php echo e($assignment->farmer->full_name ?? '—'); ?></b>
                                        <br><small style="color:var(--muted)"><?php echo e($assignment->farmer->farmer_code ?? ''); ?> • <?php echo e($assignment->farmer->phone ?? ''); ?></small>
                                    </td>
                                    <td>
                                        <b><?php echo e($assignment->taskTemplate->name ?? '—'); ?></b>
                                        <br><small style="color:var(--g700)"><?php echo e($assignment->taskTemplate->category ?? ''); ?></small>
                                    </td>
                                    <td>
                                        <span><?php echo e($assignment->location->name ?? '—'); ?></span>
                                        <br><small style="color:var(--muted)"><?php echo e($assignment->location->location_code ?? ''); ?></small>
                                    </td>
                                    <td>
                                        <b><?php echo e($assignment->scheduled_date ? $assignment->scheduled_date->format('d M, Y') : '—'); ?></b>
                                        <br><small style="color:var(--muted)"><?php echo e($assignment->formatted_time_range); ?></small>
                                        <?php if($assignment->is_past_deadline && !in_array($assignment->status, ['completed', 'cancelled'])): ?>
                                            <br><span style="font-size:10px;color:var(--red)">● সময় অতিক্রান্ত</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="pill <?php echo e($assignment->priority_badge_class); ?>">
                                            <span class="dot"></span><?php echo e($assignment->priority_label); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                            $statusMap = [
                                                'assigned' => ['label' => 'বরাদ্দকৃত', 'class' => 'blue'],
                                                'pending' => ['label' => 'বরাদ্দকৃত', 'class' => 'blue'],
                                                'in_progress' => ['label' => 'চলমান', 'class' => 'blue'],
                                                'completed' => ['label' => 'সম্পন্ন', 'class' => ''],
                                                'cancelled' => ['label' => 'বাতিল', 'class' => 'red'],
                                                'late' => ['label' => 'দেরি', 'class' => 'red'],
                                            ];
                                            $stInfo = $statusMap[$assignment->status] ?? ['label' => $assignment->status, 'class' => ''];
                                        ?>
                                        <span class="pill <?php echo e($stInfo['class']); ?>">
                                            <span class="dot"></span><?php echo e($stInfo['label']); ?>

                                        </span>
                                        <?php echo $__env->make('components.submission-health', ['assignment' => $assignment], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </td>
                                    <td>
                                        <small><?php echo e($assignment->assigner->name ?? 'অ্যাডমিন'); ?></small>
                                    </td>
                                    <td style="text-align:right">
                                        <div style="display:flex;gap:4px;justify-content:flex-end">
                                            <a href="<?php echo e(route('admin.assignments.show', $assignment)); ?>" class="btn" style="padding:4px 8px;font-size:11px">দেখুন</a>
                                            <a href="<?php echo e(route('admin.assignments.edit', $assignment)); ?>" class="btn soft" style="padding:4px 8px;font-size:11px">সম্পাদনা</a>
                                            <form method="POST" action="<?php echo e(route('admin.assignments.destroy', $assignment)); ?>" style="display:inline;" onsubmit="return confirm('আপনি কি নিশ্চিত যে এই কাজের বরাদ্দটি মুছে ফেলতে চান? এটি সফট ডিলিট হবে।');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn red" style="padding:4px 8px;font-size:11px">মুছুন</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" style="text-align:center;padding:28px 12px;color:var(--muted)">
                                        কোনো কাজের বরাদ্দ পাওয়া যায়নি।
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($assignments->hasPages()): ?>
                    <div style="margin-top:16px;">
                        <?php echo e($assignments->links()); ?>

                    </div>
                <?php endif; ?>
            </section>
        </div>

        <div>
            <section class="card">
                <div class="card-title">
                    <div class="title-left">
                        <span class="iconbox">✓</span>
                        <div>
                            <h2>সিস্টেম ও বরাদ্দ নীতিমালা</h2>
                            <div class="sub">মাঠ পর্যায়ে কাজের নিয়ন্ত্রণ ও নীতি</div>
                        </div>
                    </div>
                </div>

                <div class="rule">
                    <span>
                        <b>এক কাজ = এক কৃষক</b>
                        <div class="sub">একটি নির্দিষ্ট কাজের সময়সূচি একজন কৃষককেই কার্যকরভাবে বরাদ্দ করা হবে।</div>
                    </span>
                    <span class="pill"><span class="dot"></span>প্রয়োগকৃত</span>
                </div>

                <div class="rule">
                    <span>
                        <b>ডুপ্লিকেট বরাদ্দ প্রতিরোধ</b>
                        <div class="sub">একই কৃষককে একই তারিখে ও একই লোকেশনে পুনরায় একই কাজ বরাদ্দ করতে বাধা দেওয়া হয়।</div>
                    </span>
                    <span class="pill"><span class="dot"></span>সুরক্ষিত</span>
                </div>

                <div class="rule">
                    <span>
                        <b>রিয়েল-টাইম ক্যামেরা ও জিও-ফেন্সিং</b>
                        <div class="sub">মাঠের কাজের প্রমাণ হিসেবে নির্ধারিত বাফার রেডিয়াসের মধ্যে ছবি তুলতে হবে।</div>
                    </span>
                    <span class="pill"><span class="dot"></span>সক্রিয়</span>
                </div>
            </section>
        </div>

        <div>
            <section class="card">
                <div class="card-title">
                    <div class="title-left">
                        <span class="iconbox">⚡</span>
                        <div>
                            <h2>দ্রুত ফিল্টার অ্যাকশন</h2>
                            <div class="sub">কাজের অগ্রগতি নিরীক্ষণের সরাসরি লিংক</div>
                        </div>
                    </div>
                </div>

                <div style="display:flex;flex-direction:column;gap:8px;padding-top:4px;">
                    <a href="<?php echo e(route('admin.assignments.index', ['date_filter' => 'today'])); ?>" class="btn soft" style="justify-content:space-between;display:flex;">
                        <span>📅 আজকের নির্ধারিত সকল কাজ</span>
                        <b><?php echo e(\App\Models\TaskAssignment::whereDate('scheduled_date', today())->count()); ?>টি</b>
                    </a>
                    <a href="<?php echo e(route('admin.assignments.index', ['status' => 'in_progress'])); ?>" class="btn soft" style="justify-content:space-between;display:flex;">
                        <span>⏳ বর্তমানে চলমান কাজসমূহ</span>
                        <b><?php echo e($inProgressCount); ?>টি</b>
                    </a>
                    <a href="<?php echo e(route('admin.assignments.index', ['priority' => 'urgent'])); ?>" class="btn soft" style="justify-content:space-between;display:flex;">
                        <span>🔥 জরুরি অগ্রাধিকারপ্রাপ্ত কাজসমূহ</span>
                        <b><?php echo e(\App\Models\TaskAssignment::where('priority', 'urgent')->count()); ?>টি</b>
                    </a>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/bashir_agro_admin/resources/views/assignments/index.blade.php ENDPATH**/ ?>